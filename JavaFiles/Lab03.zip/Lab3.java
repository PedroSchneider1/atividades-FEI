
package lab3;

public class Lab3 {
    public static void main(String[] args) {
        Data data1 = new Data(27, 4, 2025);
        System.out.printf(data1.dataFormato1());
        System.out.printf(data1.dataFormato2());
        System.out.printf(data1.dataFormato3());
        
        System.out.println("");
        
        Data data2 = new Data("Fevereiro", 22, 2025);
        System.out.printf(data2.dataFormato1());
        System.out.printf(data2.dataFormato2());
        System.out.printf(data2.dataFormato3());
        
        System.out.println("");
        
        Data data3 = new Data(100, 2025);
        System.out.printf(data3.dataFormato1());
        System.out.printf(data3.dataFormato2());
        System.out.printf(data3.dataFormato3());
    }
    
}
