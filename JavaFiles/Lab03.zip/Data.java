/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

/**
 *
 * @author unifpschneider
 */
public class Data {
    private int dia;
    private int mesNumerico;
    private String mesExtenso;
    private int ano;

    public Data(int dia, int mesNumerico, int ano) {
        this.dia = dia;
        this.mesNumerico = mesNumerico;
        this.mesExtenso = this.converteMesNumerico(mesNumerico);
        this.ano = ano;
    }
    
    public Data(String mesExtenso, int dia, int ano) {
        this.dia = dia;
        this.mesExtenso = mesExtenso;
        this.mesNumerico = this.converteMesExtenso(mesExtenso);
        this.ano = ano;
    }
    
    public Data(int dia, int ano) {
        this.dia = this.converteDia(dia)[0];
        this.mesNumerico = this.converteDia(dia)[1];
        this.mesExtenso = this.converteMesNumerico(this.mesNumerico);
        this.ano = ano;
    }
    
    private String converteMesNumerico(int mes){
        String listaMeses[] = {
            "Janeiro", "Fevereiro",
            "Março", "Abril",
            "Maio", "Junho",
            "Julho", "Agosto",
            "Setembro", "Outubro",
            "Novembro", "Dezembro"};
        
        return listaMeses[mes - 1];
    }
    
    private int converteMesExtenso(String mes){
        String listaMeses[] = {
            "Janeiro", "Fevereiro",
            "Março", "Abril",
            "Maio", "Junho",
            "Julho", "Agosto",
            "Setembro", "Outubro",
            "Novembro", "Dezembro"};
        
        for(int i = 0; i < 11; i++){
            if(mes.equals(listaMeses[i]))
                return i+1;
        }
        return 0;
    }

    private int[] converteDia(int dia) {
        int retorno[] = new int[2];
        int diasMeses[] = {
            31, 28, 31, 30,
            31, 30, 31, 31,
            30, 31, 30, 31
        };

        for (int i = 0; i < 11; i++) {
            if (dia <= diasMeses[i]) {
                retorno[0] = dia;
                retorno[1] = i + 1;
                break;
            }
            dia -= diasMeses[i];
        }

        return retorno;
    }
    
    public String dataFormato1(){
        return this.dia + "/" + this.mesNumerico + "/" + this.ano + "\n";
    }
    
    public String dataFormato2(){
        return this.mesExtenso + " " + this.dia + ", " + this.ano + "\n";
    }
    
    public String dataFormato3(){
        return this.dia + " " + this.mesExtenso + " " + this.ano + "\n";
    }
}