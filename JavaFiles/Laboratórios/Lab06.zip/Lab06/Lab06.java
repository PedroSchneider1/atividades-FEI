
import Matrix.Agente;
import Matrix.Empresario;
import Matrix.Professor;
import Matrix.Advogado;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author unifpschneider
 */
public class Lab06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Agente> pessoas = new ArrayList<>();
        int n = 0;
        int opt = 0;
        
        while(opt > 1 || opt < 3){
            System.out.println("===BEM-VINDO À MATRIX===");
            System.out.println("Por favor, selecione a opção desejada:");
            System.out.println("\t1. Criar novas pessoas"
                    + "\n\t2. Apresentar todas as pessoas"
                    + "\n\t3. Sair");
            opt = sc.nextInt();
            sc.nextLine();
            
            switch(opt){
                case 1:
                    // define o numero de pessoas do array
                    System.out.printf("Digite o número de pessoas a serem criadas: ");
                    n = sc.nextInt();
                    sc.nextLine();

                    // cria as pessoas
                    for(int i = 0; i < n; i++){
                        System.out.println("Selecione a profissão da sua pessoa");
                        System.out.println("\t1. Empresário");
                        System.out.println("\t2. Professor");
                        System.out.println("\t3. Advogado");
                        opt = sc.nextInt();
                        sc.nextLine();

                        String nome;
                        switch(opt){
                            case 1:
                                String empresa;
                                System.out.printf("Digite o nome do empresário: ");
                                nome = sc.nextLine();
                                System.out.printf("Digite a empresa em que trabalha: ");
                                empresa = sc.nextLine();

                                // cria um objeto empresario
                                Agente e1 = new Empresario();
                                e1.setNome(nome);
                                e1.setProfissao("empresário");
                                ((Empresario)e1).setEmpresa(empresa);

                                pessoas.add(e1);
                                break;
                            case 2:
                                String escola;
                                System.out.printf("Digite o nome do professor: ");
                                nome = sc.nextLine();
                                System.out.printf("Digite a escola em que trabalha: ");
                                escola = sc.nextLine();

                                // cria um objeto professor
                                Agente p1 = new Professor();
                                p1.setNome(nome);
                                p1.setProfissao("professor");
                                ((Professor)p1).setEscola(escola);

                                pessoas.add(p1);
                                break;
                            case 3:
                                String OAB;
                                System.out.printf("Digite o nome do advogado: ");
                                nome = sc.nextLine();
                                System.out.printf("Digite a OAB em que trabalha: ");
                                OAB = sc.nextLine();

                                // cria um objeto advogado
                                Agente a1 = new Advogado();
                                a1.setNome(nome);
                                a1.setProfissao("advogado");
                                ((Advogado)a1).setOAB(OAB);

                                pessoas.add(a1);
                                break;
                            default:
                                System.out.println("Opção inválida.\n");
                                i--;
                        }
                    }
                    System.out.println("");
                    break;
                case 2:
                    System.out.println("Deseja inciar o processo de"
                            + "seleção de agentes? (y/n)");
                    char c = sc.next().charAt(0);
                    int n_agentes = new Random().nextInt(n);
                    
                    if(c == 'y' || c == 'Y'){
                        for(int i = 0; i < n_agentes; i++){
                            int ativa = new Random().nextInt(pessoas.size());
                            pessoas.get(ativa).modo_agente_on();
                        }
                    }
                    // apresentaçoes
                    System.out.println("");
                    for(Agente a : pessoas){
                        a.apresentacao();
                    }
                    System.out.println("");
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opção inválida.\n");
                    break;
            }
        }
    }   
}
