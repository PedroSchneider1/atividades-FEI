/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Matrix;

/**
 *
 * @author unifpschneider
 */
public class Advogado extends Agente{

    private String OAB;

    public Advogado() {
    }


    @Override
    public void apresentacao() {
        if(this.isModo_agente()){
            System.out.println("AGENTE SMITH");
        }
        else{
        System.out.println("Olá! Sou um(a) " + this.getProfissao()
                            + ", me chamo " + this.getNome()
                            + " e trabalho na OAB " + OAB);
        }
    }

    public String getOAB() {
        return OAB;
    }

    public void setOAB(String OAB) {
        this.OAB = OAB;
    }
}
