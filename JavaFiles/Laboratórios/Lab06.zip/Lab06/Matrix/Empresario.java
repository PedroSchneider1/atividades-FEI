/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Matrix;

/**
 *
 * @author unifpschneider
 */
public class Empresario extends Agente{

    private String empresa;

    public Empresario() {
    }


    @Override
    public void apresentacao() {
        if(this.isModo_agente()){
            System.out.println("AGENTE SMITH");
        }
        else{
        System.out.println("Olá! Sou um(a) " + this.getProfissao()
                            + ", me chamo " + this.getNome()
                            + " e trabalho na empresa " + empresa);
        }
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
}
