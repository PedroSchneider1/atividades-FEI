/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Matrix;

/**
 *
 * @author unifpschneider
 */
public class Professor extends Agente{

    private String escola;

    public Professor() {
    }


    @Override
    public void apresentacao() {
        if(this.isModo_agente()){
            System.out.println("AGENTE SMITH");
        }
        else{
        System.out.println("Olá! Sou um(a) " + this.getProfissao()
                            + ", me chamo " + this.getNome()
                            + " e trabalho na escola " + escola);
        }
    }

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }
}
