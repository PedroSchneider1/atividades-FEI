/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

/**
 *
 * @author unifpschneider
 */
public class Pessoa {
    protected String nome;
    protected long cpf;
    protected Data nascimento;

    public Pessoa(String nome,
                    long cpf,
                    Data nascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.nascimento = nascimento;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Nome: " + nome
                + "\nCPF: " + cpf
                + "\nDt. Nascimento: " + nascimento;
    }
    
    
}
