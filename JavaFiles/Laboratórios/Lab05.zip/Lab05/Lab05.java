
import Sistema.Data;
import Sistema.Funcionario;
import Sistema.Gerente;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author unifpschneider
 */
public class Lab05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList <Funcionario> funcionarios = new ArrayList<>();
        ArrayList <Gerente> gerentes = new ArrayList<>();
        
        for(int i = 0; i < 1; i++){
            // coleta de dados para a criação dos objetos
            System.out.println("==CADASTRO DE FUNCIONARIOS==");
            System.out.println("Digite o nome do funcionario: ");
            String nome = sc.nextLine();
            System.out.println("Digite o CPF do funcionario: ");
            long CPF = sc.nextLong();
            System.out.println("Digite a data de nascimento do funcionario (dd mm yyyy): ");
            int diaNasc = sc.nextInt();
            int mesNasc = sc.nextInt();
            int anoNasc = sc.nextInt();
            Data nasc = new Data(diaNasc, mesNasc, anoNasc);
            // limpa buffer
            sc.nextLine();
            
            System.out.println("Digite a data de admissão do funcionario (dd mm yyyy): ");
            int diaAdm = sc.nextInt();
            int mesAdm = sc.nextInt();
            int anoAdm = sc.nextInt();
            Data adm = new Data(diaAdm, mesAdm, anoAdm);
            // limpa buffer
            sc.nextLine();

            System.out.println("Digite o salário do funcionario (R$): ");
            double salario = sc.nextDouble();
            // limpa buffer
            sc.nextLine();
            
            // cria o objeto da classe Funcionario e adiciona no array list
            Funcionario f1 = new Funcionario(nome, CPF, nasc, adm, salario);
            funcionarios.add(f1);
        }
        
        for(int i = 0; i < 1; i++){
            // coleta de dados para a criação dos objetos
            System.out.println("==CADASTRO DE GERENTES==");
            System.out.println("Digite o nome do gerente: ");
            String nome = sc.nextLine();
            System.out.println("Digite o CPF do gerente: ");
            long CPF = sc.nextLong();
            System.out.println("Digite a data de nascimento do gerente (dd mm yyyy): ");
            int diaNasc = sc.nextInt();
            int mesNasc = sc.nextInt();
            int anoNasc = sc.nextInt();
            Data nasc = new Data(diaNasc, mesNasc, anoNasc);
            // limpa buffer
            sc.nextLine();
            
            System.out.println("Digite a data de admissão do gerente (dd mm yyyy): ");
            int diaAdm = sc.nextInt();
            int mesAdm = sc.nextInt();
            int anoAdm = sc.nextInt();
            Data adm = new Data(diaAdm, mesAdm, anoAdm);
            // limpa buffer
            sc.nextLine();

            System.out.println("Digite a data de promoção do gerente (dd mm yyyy): ");
            int diaPromo = sc.nextInt();
            int mesPromo = sc.nextInt();
            int anoPromo = sc.nextInt();
            Data promo = new Data(diaPromo, mesPromo, anoPromo);
            // limpa buffer
            sc.nextLine();
            
            System.out.println("Digite o salário do gerente (R$): ");
            double salario = sc.nextDouble();
            
            System.out.println("Digite o departamento do gerente: ");
            int dept = sc.nextInt();
            // limpa buffer
            sc.nextLine();
            
            // cria o objeto da classe Gerente e adiciona no array list
            Gerente g1 = new Gerente(nome, CPF, nasc, adm, salario, dept, promo);
            gerentes.add(g1);
        }
        
        // imprime os objetos
        for(Funcionario f : funcionarios){
            System.out.println(f);
        }
        System.out.println("");
        for(Gerente g : gerentes){
            System.out.println(g);
        }
        
        sc.close();
    }
    
}
