/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author unifpschneider
 */
public class ListaUsuarios {
    public Usuario listar(ArrayList<Usuario> usuarios, String CPF){
        for(Usuario u : usuarios){
            if(u.getCPF().equals(CPF)){
                return u;
            }
        }
        return null;
    }
}
