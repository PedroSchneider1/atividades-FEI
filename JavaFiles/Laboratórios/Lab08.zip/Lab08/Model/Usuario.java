/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author unifpschneider
 */
public class Usuario {
    private String nome, sobrenome, CPF, sexo;
    private int idade;

    public Usuario(String nome, String sobrenome, String CPF, int idade, String sexo) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.CPF = CPF;
        this.idade = (idade >= 0) ? idade : 0; // checa se a idade é positiva, se não assimila 0
        this.sexo = sexo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    

    @Override
    public String toString() {
        return "Nome completo: " + nome + " " + sobrenome
                + " | Sexo: " + sexo
                + " | CPF: " + CPF
                + " | Idade: " + idade;
    }
    
    
    
}
