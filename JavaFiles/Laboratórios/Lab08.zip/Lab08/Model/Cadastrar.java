/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author unifpschneider
 */
public class Cadastrar {
    public Usuario cadastrar(String nome, String sobrenome, String CPF, int idade, String sexo){
        Usuario u = new Usuario(nome, sobrenome, CPF, idade, sexo);
        return u;
    }
}
