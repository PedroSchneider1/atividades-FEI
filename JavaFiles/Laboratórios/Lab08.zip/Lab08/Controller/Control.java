/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Cadastrar;
import Model.ListaUsuarios;
import Model.Usuario;
import View.Busca;
import View.Cadastro;
import java.util.ArrayList;

/**
 *
 * @author unifpschneider
 */
public class Control {
    private Cadastro c;
    private Busca b;
    ArrayList<Usuario> usuarios = new ArrayList<>();
    
    public Control(Cadastro c) {
        this.c = c;
    }

    public Control(Busca b, ArrayList<Usuario> u) {
        this.b = b;
        this.usuarios = u;
    }

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void controlCadastra(){
        String nome, sobrenome, CPF, sexo = "Não selecionado";
        int idade;
        
        nome = c.getTxt_nome().getText();
        sobrenome = c.getTxt_sobrenome().getText();
        CPF = c.getTxt_CPF().getText();
        
        if(c.getBtt_fem().isSelected()){
            sexo = "Feminino";
        }
        else if(c.getBtt_masc().isSelected()){
            sexo = "Masculino";
        }
        
        idade = Integer.parseInt(c.getTxt_idade().getText());
        Cadastrar cad = new Cadastrar();
        usuarios.add(cad.cadastrar(nome, sobrenome, CPF, idade, sexo));
        
        c.getTxt_nome().setText("");
        c.getTxt_sobrenome().setText("");
        c.getTxt_idade().setText("");
        c.getTxt_CPF().setText("");
    }
    
    public void controlListar(){
        if (usuarios.isEmpty()) {
            b.getTxt_listaCPF().setText("Nenhum usuário cadastrado.");
        } else {
            ListaUsuarios l = new ListaUsuarios();
            Usuario u = l.listar(usuarios, b.getTxt_buscarCPF().getText());
            
            if(u == null){
                b.getTxt_listaCPF().setText("Usuário não encontrado.");
            }
            else{
                b.getTxt_listaCPF().setText(u.toString());
            }
        }
    }
}
