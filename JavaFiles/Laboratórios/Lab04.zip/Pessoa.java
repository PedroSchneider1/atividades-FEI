/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula08ex01;

/**
 *
 * @author unifpschneider
 */
public class Pessoa {
    private String nome;
    private int telefone;
    private int id_individual = 1;
    private static int id_geral = 0;

    public Pessoa(String nome, int telefone) {
        this.nome = nome;
        this.telefone = telefone;
        this.id_individual += id_geral++;
    }
    
    public String getNome() {
        return nome;
    }

    public int getTelefone() {
        return telefone;
    }

    public int getId() {
        return id_individual;
    }
}
