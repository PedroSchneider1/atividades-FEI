/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula08ex01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifpschneider
 */
public class Agenda {
    public static void main(String[] args) {
        // inicializa variaveis
        Scanner sc = new Scanner(System.in);
        ArrayList <Pessoa> agenda = new ArrayList<>();
        char opt = '0';
        
        while(opt != 'q' && opt != 'Q'){
            // menu
            System.out.println("Entre com uma das seguintes opções:");
            System.out.println("\tn [nova entrada]");
            System.out.println("\td [apaga registro da agenda]");
            System.out.println("\tp [imprime toda a agenda]");
            System.out.println("\tq [sair]");
            
            opt = sc.next().charAt(0);
            
            switch (opt) {
                case 'n', 'N' -> {
                    // declara parametros do objeto
                    String nome;
                    int telefone;
                    
                    // limpa buffer
                    sc.nextLine();
                    System.out.println("Digite o nome da pessoa a ser adicionada: ");
                    nome = sc.nextLine();
                    System.out.println("Digite o telefone da pessoa a ser adicionada: ");
                    telefone = sc.nextInt();
                    
                    // cria objeto e adiciona no arraylist
                    Pessoa p1 = new Pessoa(nome, telefone);
                    agenda.add(p1);
                }
                case 'd', 'D' -> {
                    // declara variavel
                    String nome;
                    
                    // limpa buffer
                    sc.nextLine();
                    System.out.println("Digite o nome da pessoa a ser removida: ");
                    nome = sc.nextLine();
                    
                    // remove objeto do arraylist
                    for(int i = 0; i < agenda.size(); i++){
                        if(agenda.get(i).getNome().equalsIgnoreCase(nome)){
                            agenda.remove(i);
                            break;
                        }
                    }
                }
                case 'p', 'P' -> {
                    // for-each para cada objeto no arraylist
                    for(Pessoa pessoa : agenda){
                        System.out.println("ID: " + pessoa.getId());
                        System.out.println("Nome: " + pessoa.getNome());
                        System.out.println("Telefone: " + pessoa.getTelefone());
                        System.out.println("---------------------------------");
                    }
                }
                default -> {
                    break;
                }
            }
        }
    }
}
