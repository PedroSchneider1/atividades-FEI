# # O Máximo Divisor Comum (MDC) de dois números inteiros positivos, n e m, é o maior número, d, que divide de forma inteira n e m.
# Faça um programa em Python que leia dois números inteiros positivos do usuário, determina e reporta o maior divisor comum entre eles.

n = int(input("Digite n: "))
m = int(input("Digite m: "))

if n > m:
    d = m
else:
    d = n

while (d > 0):
    if (n % d == 0) and (m % d == 0):
        break
    d -= 1

print(d)