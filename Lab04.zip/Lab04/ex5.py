# Faça um programa que receba valores do teclado até o usuário digitar zero e imprima a soma de todos os valores digitados.

x = int(input())
soma = 0

while x != 0:
    soma = soma + x
    x = int(input())
    
print("Resultado:", soma)