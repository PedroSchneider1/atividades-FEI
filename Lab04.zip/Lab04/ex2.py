# Faça um programa que leia um valor N inteiro e positivo, calcule e mostre o valor de E, conforme a fórmula a seguir: 
# S = 1 + 1/1 + 1/2 + 1/3 + ... + 1/N

num = int(input("Digite o número desejado: "))

if num == 0:
  print("Número inválido")

else:
  soma = 1
  for i in range(1, num + 1):
    soma += 1 / i
  print("%.3f" % soma)