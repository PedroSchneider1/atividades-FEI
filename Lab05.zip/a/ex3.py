# Faça um programa que receba um número inteiro maior que 1 e verifique se o número fornecido é primo ou não. Mostre uma mensagem de número primo ou de número não primo. Um número é primo quando é divisível apenas pelo número um e por ele mesmo.

import math

num = int(input(f"Digite o número desejado: "))
a = 0

if num <= 1: # Nao é primo
    print("Número não primo")
elif num == 2: # É primo
    print("Número primo")

raiz = int(math.sqrt(num))+1
for j in range(2, raiz):
    if num % j == 0:
        print("Número não primo")
        a = 1
        break
if a != 1:
    print("Número primo")
