# Você deve fazer um programa que apresente a sequencia conforme o exemplo abaixo.
"""
I=1 J=60
I=4 J=55
I=7 J=50
...
I=? J=0
"""
j = 60
i = 1
while(j >= 0):
    print(f"I={i}", f"J={j}")
    j -= 5
    i += 3