# Escreva um programa que leia um valor inteiro n, onde n é a quantidade de linhas de saída que serão apresentadas na execução do programa.
"""
Input           Output
3       Digite a quantidade de linhas: 3
                1 1 1
                2 4 8
                3 9 27
"""

from math import pow

n = int(input("Digite a quantidade de linhas: "))

for i in range(1, n+1):
    for x in range(1, 4):
        x = pow(i, x)
        print(int(x), end=' ')
    print(' ')