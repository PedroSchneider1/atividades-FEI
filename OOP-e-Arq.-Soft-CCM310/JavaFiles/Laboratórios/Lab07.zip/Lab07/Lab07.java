import Exceptions.CPFException;
import Pessoas.Pessoa;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author unifpschneider
 */
public class Lab07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Pessoa p1 = null;
        
        System.out.print("Digite o nome: ");
        String nome = sc.nextLine();

        System.out.print("Digite o sobrenome: ");
        String sobrenome = sc.nextLine();

        System.out.print("Digite a idade: ");
        int idade = sc.nextInt();
        sc.nextLine(); // limpa buffer

        while(p1 == null){
            try{
                System.out.print("Digite o CPF (sem pontos ou hífens): ");
                String cpf = sc.nextLine();

                p1 = new Pessoa(nome, sobrenome, cpf, idade);
            }
            catch(CPFException e){
                System.out.println("");
                System.err.println(e.getMessage());
                System.out.println("Por favor, digite o CPF novamente.");
                continue;
            }
            
            System.out.println("");
            System.out.println("Pessoa criada com sucesso!");
            System.out.println(p1);
        }
        sc.close();
    }
    
}
