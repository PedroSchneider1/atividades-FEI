/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoas;
import Exceptions.CPFException;

/**
 *
 * @author unifpschneider
 */
public class Pessoa {
    private String nome, sobrenome, CPF;
    private int idade;

    public Pessoa(
            String nome,
            String sobrenome,
            String CPF,
            int idade
            ) throws CPFException {
        if(CPF.contains(".") || CPF.contains("-")){
            throw new CPFException("Erro: CPF não deve conter"
                    + "caracteres especiais (pontos ou hífens).");
        }
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.CPF = CPF;
        this.idade = idade;
    }
    
    @Override
    public String toString() {
        return "Pessoa [nome=" + nome + ", sobrenome=" + sobrenome
                + ", idade=" + idade + ", CPF=" + CPF + "]";
    }
}